/**
 * Created by Gor on 7/13/2017.
 */

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class HistogramLetters {
    private int m_n;
    private Scanner input;
    private List<Double> chart_prob_results = new ArrayList<>(m_n);
    private List<Character> chart_letter_results = new ArrayList<>(m_n);

    public HistogramLetters(int occurrence)
    {
        this.m_n = occurrence;

        for (int i = 0; i < chart_letter_results.size(); i++)
        {
            chart_letter_results.add('a');
        }

        for (int j = 0; j < chart_prob_results.size(); j++)
        {
            chart_prob_results.add(0.0);
        }
    }

    public void readFile() {

            for (char ch = 'a'; ch <= 'z'; ch++)
            {
                double total_count = 0;
                double letter_count = 0;

                try
                {
                    input = new Scanner(Paths.get("Test.txt"));
                }

                catch (IOException Except)
                {
                    System.err.println("Error opening file.");
                    System.exit(1);
                }

                while (input.hasNext())
                {
                    String str = input.next();
                    for (int count = 0; count < str.length(); count++)
                    {
                        char c = str.charAt(count);
                        if ( (Character.isLetter(c))) {total_count++;}
                        if ( (Character.toLowerCase(c) == ch) || (Character.toUpperCase(c) == ch) ){letter_count ++;}
                    }
                }
                System.out.printf("%s : %s%n",ch ,letter_count);
                double prob = letter_count / total_count;

                for (int i = 0; i < chart_prob_results.size(); i++) {
                    if (chart_prob_results.get(i) < prob) {
                        //UPDATE THE NTH GREATEST OCCURRENCE PROB.
                        chart_prob_results.set(i, prob);
                        //STORE THE LETTER IN THE CORRESPONDING INDEX FOR THE PIE CHART
                        chart_letter_results.set(i, ch);
                    }
                }
                System.out.println(chart_letter_results);

                if (input != null)
                {
                    input.close();
                }
            }
    }


    public void setN(int n) {m_n = n;}

    public int getN() {return m_n;}

    public double getLetter(int index){return chart_letter_results.get(index);}

    public double getProb(int index){return chart_prob_results.get(index);}

    public int getSize() {return chart_letter_results.size();}
}
