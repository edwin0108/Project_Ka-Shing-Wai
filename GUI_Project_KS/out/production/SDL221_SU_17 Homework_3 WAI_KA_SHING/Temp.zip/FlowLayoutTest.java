import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Gor on 7/15/2017.
 */

public class FlowLayoutTest extends JFrame{
    private JButton b2;
    private JTextField t1;
    private JLabel l1;


    public FlowLayoutTest()
    {

        setLayout(new FlowLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600,400);
        //b1 = new JButton("Request for new Panel");

        b2 = new JButton("Enter");

        t1 = new JTextField("Type here");
        t1.setPreferredSize(new Dimension(100,25));

        l1 = new JLabel("                Number of occurrence: ");

        ButtonControl handler = new ButtonControl();
        b2.addActionListener(handler);

        add(l1, FlowLayout.LEFT);
        add(t1, FlowLayout.CENTER);
        add(b2, FlowLayout.RIGHT);
        //add(b1, FlowLayout.LEFT);

    }

    private class ButtonControl implements ActionListener
    {
        @Override
        public void actionPerformed (ActionEvent e)
        {
            HistogramLetters.openFile();            //OPEN THE FILE
            int x = Integer.parseInt(t1.getText()); //CONVERT INPUT STRING TO INT
            HistogramLetters.setN(x);              //SET THE # OCCURRENCE TO THE CLASS AND PROCESS
            HistogramLetters.readFile();
            JPanel jp1 = new MyPieChartPanel();
            add(jp1);
            HistogramLetters.closeFile();
        }
    }

    class MyPieChartPanel extends JPanel
    {
        @Override
        public void paintComponent(Graphics g)
        {
            super.paintComponent(g);
            Arc a = new Arc(getWidth() / 2, getHeight() / 2, getHeight() / 2,
                    Color.CYAN, getWidth(), getHeight(), 0);
            a.draw(g);
        }
    }
}
