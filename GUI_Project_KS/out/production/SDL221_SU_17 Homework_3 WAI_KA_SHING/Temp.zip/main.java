import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

/**
 * Created by Gor on 07/08/2017.
 */
public class main {

    public static void main(String[] args)
    {
        //Layout_Test panel = new Layout_Test();
        //panel.process();

        FlowLayoutTest a1 = new FlowLayoutTest();
        a1.setSize(600,400);
        a1.setVisible(true);

        //GridBagLayoutTest frame = new GridBagLayoutTest();
        //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame.setVisible(true);

        //Border_Layout frame = new Border_Layout();
        //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame.setSize(600,400);
        //frame.setVisible(true);

        /*List<Character> a = new ArrayList<>(4);
        a.add(0,'a');
        a.add(1,'a');
        a.add(2,'a');
        a.add(3,'a');
        System.out.println(a);
        a.set(2,'b');
        System.out.println(a);
*/

        //HistogramLetters.openFile();
        //HistogramLetters.readFile();
        //HistogramLetters.closeFile();

        /*int width;
        int height;

        Scanner input = new Scanner(System.in);
        System.out.printf("Please enter the width:");
        width = input.nextInt();
        System.out.printf("Please enter the height:");
        height = input.nextInt();

        Test panel = new Test();
        JFrame application = new JFrame();
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        application.add(panel);
        application.setTitle("Assignment 4 - Ka Shing Wai");
        application.setSize(width,height);
        application.setVisible(true);
*/
    }

}
