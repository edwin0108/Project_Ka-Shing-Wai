import java.awt.*;
import java.util.Random;

/**
 * Created by Gor on 7/11/2017.
 */
public class Arc {
    private Color arc_color;
    private int m_start_angle;
    private int m_angle;
    private int m_x, m_y, m_radius, m_width, m_height;

    public Arc(int x, int y, int radius, Color color, int width, int height, int start_angle){
        this.m_x = x;
        this.m_y = y;
        this.m_radius = radius;
        this.arc_color = color;
        this.m_width = width;
        this.m_height = height;
        this.m_start_angle = start_angle;
    }

    public void setAngle(int angle) {m_angle = angle;}

    public void setStartAngle(int angle) {m_start_angle = angle;}

    public int getX() {return m_x;}

    public int getY() {return m_y;}

    public int getRadius() {return m_radius;}

    public int getAngle() {return m_angle;}

    public int getWidth() {return m_width;}

    public int getHeight() {return m_height;}

    public int getStartAngle() {return m_start_angle;}

    public Color getColor() {return arc_color;}

    public Color setColor()
    {
        Random ran_color = new Random();
        Color randomColor = new Color((int)ran_color.nextInt(255),
                (int)ran_color.nextInt(255),
                (int)ran_color.nextInt(255));
        arc_color = randomColor;
        return randomColor;
    }

    public void draw(Graphics g)
    {
        g.setColor(Color.black);
        g.drawOval((getWidth() - getHeight())/2, 30,getHeight() - 30, getHeight() - 30);
        for (int i = 0; i < HistogramLetters.getSize(); i++)
        {
            int angle = (int)(HistogramLetters.getProb(i) * 360);
            setAngle(angle);
            g.setColor(setColor());
            g.fillArc((getWidth() - getHeight())/2, 30, getHeight() - 30, getHeight() - 30,getStartAngle(),getAngle());
            setStartAngle(getStartAngle() + getAngle());
        }
    }
}
