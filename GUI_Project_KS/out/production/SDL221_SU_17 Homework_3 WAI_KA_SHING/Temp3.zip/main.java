import javax.swing.*;

/**
 * Created by Gor on 07/08/2017.
 */
public class main {
    public static void main(String[] args)
    {
        FlowLayoutTest a1 = new FlowLayoutTest();
        a1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        a1.setVisible(true);
    }
}
