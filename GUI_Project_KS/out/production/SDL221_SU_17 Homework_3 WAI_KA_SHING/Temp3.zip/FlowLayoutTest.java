import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Gor on 7/15/2017.
 */

public class FlowLayoutTest extends JFrame{
    private JButton b2;
    private JTextField t1;
    private JLabel l1;
    private final MyPieChartPanel jp1;


    public FlowLayoutTest()
    {
        setLayout(new FlowLayout());
        setSize(900,700);


        b2 = new JButton("Enter");

        t1 = new JTextField("7");
        t1.setPreferredSize(new Dimension(100,25));

        l1 = new JLabel("             Number of occurrence: ");

        ButtonControl handler = new ButtonControl();
        b2.addActionListener(handler);

        jp1 = new MyPieChartPanel();
        jp1.setPreferredSize(new Dimension(800,500));

        add(l1);
        add(t1);
        add(b2);
        add(jp1);
        //add(b1, FlowLayout.LEFT);

    }

    private class ButtonControl implements ActionListener
    {
        @Override
        public void actionPerformed (ActionEvent e)
        {
            int x = Integer.parseInt(t1.getText());
            HistogramLetters test = new HistogramLetters(x);
            test.openFile();
            test.readFile();
            repaint();
            test.closeFile();
        }
    }

    class MyPieChartPanel extends JPanel
    {
        @Override
        public void paintComponent(Graphics g)
        {
            super.paintComponent(g);
            int num_arc = Integer.parseInt(t1.getText());
            PieChart a = new PieChart(getWidth() / 2, getHeight() / 2, getHeight() / 2,
                    Color.CYAN, getWidth(), getHeight(), 0, num_arc);
            a.draw(g);
        }
    }
}
